from .Bayes_modules.BayesLinear import BayesLinear as BBB_LRT_Linear
from .Bayes_modules.BayesConv import BayesConv1d as BBB_LRT_Conv1d

from .misc import FlattenLayer, ModuleWrapper
